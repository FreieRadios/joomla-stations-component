<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_stations
 *
 * @copyright   (C) 2022, Michael Liebler
 * @license     GNU
 */

namespace Joomla\Component\Stations\Administrator\Helper;

use Joomla\CMS\Form\Form;
use Joomla\CMS\Helper\ContentHelper;

\defined('_JEXEC') or die('Restricted Direct Access!');

class StationsHelper extends ContentHelper
{
}