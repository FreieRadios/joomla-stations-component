<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_stations
 *
 * @copyright   (C) 2022, Michael Liebler
 * @license     GNU
 */

\defined('JPATH_PLATFORM') or die('Restricted Direct Access!');

/**
 * Helper class for the component.
 *
 * @since	3.0
 */
class StationsHelper extends Joomla\Component\Stations\Administrator\Helper\StationsHelper
{
}
