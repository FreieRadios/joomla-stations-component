<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_stations
 *
 * @copyright   (C) 2022, Michael Liebler
 * @license     GNU
 */

namespace Joomla\Component\Stations\Site\Controller;

\defined('_JEXEC') or die('Restricted Direct Access!');

use Joomla\CMS\MVC\Controller\BaseController;


/**
 * Destinations controller class.
 *
 * @since	1.0.0
 */
class DestinationsController extends BaseController
{
}
